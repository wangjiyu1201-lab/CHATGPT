#!/bin/bash
cd -- "$(dirname -- "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then
  python3 launch.py
else
  echo "Please install Python 3 from https://www.python.org/downloads/macos/"
fi
echo "Press Return to close this window."
read -r
